import sys
from pathlib import Path

# ensure project root is on sys.path so `app` can be imported when running from tests/
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import app

with app.test_client() as client:
    # Simulate admin login in session
    with client.session_transaction() as sess:
        sess['user_id'] = 1
        sess['role'] = 'admin'

    resp = client.get('/admin/add_hall')
    html = resp.get_data(as_text=True)

    print('STATUS_CODE:', resp.status_code)
    print('HAS_RADIO_3:', 'name="col_choice"' in html and 'value="3"' in html)
    print('HAS_RADIO_6:', 'value="6"' in html)
    print('HAS_RADIO_9:', 'value="9"' in html)
    print('HAS_HIDDEN_total_columns:', 'name="total_columns"' in html)
    print('HAS_HIDDEN_columns:', 'name="columns"' in html)
    # Print a short snippet
    start = html.find('Columns')
    print('\nSNIPPET:\n', html[start:start+400])
